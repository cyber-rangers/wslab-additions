﻿#protected
$ComputerName = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\DEMO -Name ServerForInvokeCommand
Invoke-Command -ComputerName dc.gopas.virtual -ScriptBlock {gip | select InterfaceAlias,IPv4Address}

#or interactive
$ComputerName = Read-Host "Enter server name FQDN"
Invoke-Command -ComputerName dc.gopas.virtual -ScriptBlock {gip | select InterfaceAlias,IPv4Address}
