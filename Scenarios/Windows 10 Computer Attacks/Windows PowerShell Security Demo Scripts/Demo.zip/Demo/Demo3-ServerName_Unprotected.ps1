﻿#unprotected
Invoke-Command -ComputerName dc.gopas.virtual -ScriptBlock {gip | select InterfaceAlias,IPv4Address}