﻿param($processname)
Get-Process -ProcessName $processname