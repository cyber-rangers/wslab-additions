﻿ $credential = New-Object System.Management.Automation.PSCredential('GOPAS\domain-admin',$(ConvertTo-SecureString -AsPlainText -Force -String 'P@ssw0rd'))

 Get-WmiObject -Class win32_computersystem -ComputerName dc.gopas.virtual -Credential $credential