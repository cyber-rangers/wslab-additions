﻿$UserName = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\DEMO -Name Username
$Password = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\DEMO -Name Password

$credential = New-Object System.Management.Automation.PSCredential($UserName,$(ConvertTo-SecureString -AsPlainText -Force -String $Password))

#still password "visible"
$credential.GetNetworkCredential().Password

#but unprotected servername :)
Get-WmiObject -Class win32_computersystem -ComputerName dc.gopas.virtual -Credential $credential