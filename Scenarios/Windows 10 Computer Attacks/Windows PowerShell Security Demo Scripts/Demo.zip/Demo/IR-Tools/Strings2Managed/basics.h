#pragma once

#include <windows.h>
#include <strsafe.h>

void PrintLastError(LPTSTR lpszFunction); 