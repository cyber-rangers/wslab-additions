﻿Get-ChildItem C:\Demo\IR-Tools -Recurse | Unblock-File

Import-Module C:\Demo\IR-Tools\Get-ShellContent.ps1

<#
cmd.exe
procdump -ma 1234
Get-ShellContent -ProcDump C:\Demo\Demo3-Dump.dmp
#>

Get-ShellContent -ProcessID 2296